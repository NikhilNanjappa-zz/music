def merge(v1,v2)
sum=v1+v2
puts "The result is #{sum}"
end


puts "Enter the 1st value"
v1 = gets.chomp
puts "Enter the 2nd value"
v2 = gets.chomp

if( v1 =~ /[a-z]/ && v2 =~ /[a-z]/)
	merge(v1,v2)
elsif(v1 =~ /[0-9]/ && v2 =~ /[0-9]/)
	v1=v1.to_i
	v2=v2.to_i
	merge(v1,v2)
else
	puts "Both are different types"
end