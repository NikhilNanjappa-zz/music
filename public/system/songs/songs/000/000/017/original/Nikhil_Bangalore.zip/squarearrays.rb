puts "Enter the number of inputs in the array"
numb = Array.new(Integer(gets));

abc=Array.new
puts "Enter the numbers"

for i in 1..(numb.length)
n=Integer(gets)
abc=abc.push(n)
end

#puts abc.inspect
abc=abc.collect {|x| x*x}
puts "Squared numbers are :"
for ele in abc
puts ele
end
