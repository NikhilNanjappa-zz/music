
player_hash = { }
input = ""
name = ""
position = ""

print "Enter inputs in the format name-position; or just press ENTER to quit=>"
input = gets.chomp

while input != "" do
(name, position) = input.split("-")	
player_hash[name] = position
print "Enter inputs in the format name-position; or just press ENTER to quit=>"
input = gets.chomp
end

player_hash.each do |key,value|
puts "#{key} is a #{value}."
end