puts "Enter the string"
s = gets.chomp
s=s.downcase!

for i in 0..(s.length)-1
	s[i]=s[i].upcase! if i%2==0
end

puts s