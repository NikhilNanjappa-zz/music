class Student

def sort(s)
puts "Sort based on? age/name/roll?"
params=gets.chomp
sorted_array=Array.new
   if(params=="name")
	sorted_array=s.sort_by{|x|[x.name]}
elsif(params=="age")
	sorted_array=s.sort_by{|x|[x.age]}
elsif(params=="roll")
	sorted_array=s.sort_by{|x|[x.roll]}
else
	puts "Invalid entry"
end
puts "Sorted Objects based on #{params} are:"
sorted_array.each do |x|
puts "Roll_ID is:#{x.roll}","Name is:#{x.name}","Age is:#{x.age}","Gender:#{x.gender}"
puts "------------------------"
end
end

def roll
	@roll
end
def roll=(val)
	@roll=val
end
def name
	@name
end
def name=(val)
	@name=val
end

def age
	@age
end
def age=(val)
	@age=val
end

def gender
	@gender
end
def gender=(val)
	@gender=val
end
end

class Enroll < Student

puts "Enter the number of students to enroll:"
n=Integer(gets.chomp)
s=Array.new(n)                       #creating an array of objects depending on the number of entries by the user

for i in 0..n-1
s[i] = Student.new                   #creating an object in the array "s" for each entry
s[i].roll=1 if i==0                  #assigning the roll id for the first iteration
s[i].roll=s[i-1].roll+1 if i>0       #auto generating roll id for the next iterations
puts "Enter the Name:"
s[i].name=gets.chomp
puts "Enter the Age:"
s[i].age=Integer(gets.chomp)
puts "Enter the Gender:"
s[i].gender=gets.chomp
end

stu=Student.new
stu.sort(s)
end