module Automobile

end

class Vehicle
include Automobile

def initialize(vehicle,wheels,color,price,brand)
	puts "#{vehicle} has #{wheels} wheels"
	puts "#{vehicle} is available in #{color} color"
	puts "Cost of the #{vehicle} is #{price}"
	puts "Brand of the #{vehicle} is #{brand}"
end
end

class Bike < Vehicle

end

class Car < Vehicle

end

class Bus < Vehicle 

end

puts "What you want to know about ? Bike/Car/Bus?"
vehicle=gets.chomp
bi=Bike.new vehicle,"2","Black","120000","KTM" if vehicle=="Bike"
bu=Bus.new vehicle,"6","Red","1000000","VOLVO" if vehicle=="Bus"
ca=Car.new vehicle,"4","White","450000","Skoda" if vehicle=="Car"