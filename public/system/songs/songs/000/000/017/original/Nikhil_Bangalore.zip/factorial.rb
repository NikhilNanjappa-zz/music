def fact (n)
  if n== 0
    1
  else
   n* fact(n-1) 	
  end
end

puts "Enter the number to which fatorial has to be calculated ?"
n=gets
result=fact(Integer(n))
puts "factorial is #{result}"

